from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        labels = {
            'username': "Nom d'utilisateur",
            'email': "Adresse e-mail",
            'password1': "Mot de passe",
            'password2': "Confirmation du mot de passe",
        }
        help_texts = {
            'username': "150 caractères max. Lettres, chiffres et @/./+/-/_ uniquement.",
            'password1': (
                "Le mot de passe ne doit pas être trop similaire à vos informations personnelles. "
                "Il doit contenir au moins 8 caractères, ne pas être un mot trop courant ni entièrement numérique."
            ),
            'password2': "Entrez le même mot de passe que ci-dessus, pour vérification.",
        }
