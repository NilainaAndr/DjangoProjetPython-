Romanga **Romanga** est une plateforme web dédiée à la lecture de **bandes dessinées**, **mangas** et **webtoons** dans le genre **Romance**. Il propose une interface élégante, douce et immersive, pensée pour les fans d'histoires d'amour illustrées. --- 
Fonctionnalités -  Lecture de mangas, BD et webtoons - 
Catégorisation de genres romances uniquement
Interface Admin pour les CRUD   
Authentification et gestion des utilisateurs 
Technologies - **Backend** : Django (Python) - **Frontend** : HTML5, CSS3, - **Base de données** : MySQL - **Gestion d'images** : Django Media  - **Authentification** : Django auth, - **Design UI** : Logo romantique, palette pastel, UX orientée douceur --- 
Lancer le projet en local (Utilisateur) : http://127.0.0.1:8000/
Lancer le projet en Admin (Administrateur) : http://127.0.0.1:8000/admin/ 