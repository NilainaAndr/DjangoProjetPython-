from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from .forms import RegisterForm
from .models import Manga, Chapter, Page
from django.shortcuts import get_object_or_404

def home(request):
    nouveautés = Manga.objects.all()  # Récupérer tous les mangas pour la section Nouveautés
    top10 = Manga.objects.order_by('-created_at')[:10]  # Récupérer les 10 derniers mangas
    return render(request, 'reader/home.html', {
        'mangas': nouveautés,  # Pour la liste générale
        'nouveautés': nouveautés,
        'top10': top10,
    })

def novelty(request):
    nouveautés = Manga.objects.all()  
    return render(request, 'reader/novelty.html', {'nouveautés': nouveautés})

def top_10(request):
    top10 = Manga.objects.order_by('-created_at')[:10]  # Exemple pour obtenir les 10 derniers
    return render(request, 'reader/TOP_10.html', {'top10': top10})

def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = RegisterForm()
    return render(request, 'reader/register.html', {'form': form})

def login_view(request):
    if request.method == "POST":
        user = authenticate(request, username=request.POST['username'], password=request.POST['password'])
        if user:
            login(request, user)
            return redirect('home')
    return render(request, 'reader/login.html')

def logout_view(request):
    logout(request)
    return render(request, 'reader/logout.html')  # Affiche la page de déconnexion


def manga_detail(request, manga_id):
    manga = get_object_or_404(Manga, id=manga_id)
    chapters = manga.chapters.all()  # Grâce à related_name='chapters'
    return render(request, 'reader/manga_detail.html', {
        'manga': manga,
        'chapters': chapters
    })

def read_chapter(request, chapter_id):
    chapter = get_object_or_404(Chapter, id=chapter_id)
    pages = chapter.pages.all()  # si related_name='pages' dans Page
    return render(request, 'reader/read_chapter.html', {
        'chapter': chapter,
        'pages': pages
    })

