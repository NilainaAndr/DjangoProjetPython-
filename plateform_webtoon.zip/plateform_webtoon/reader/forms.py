from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

class RegisterForm(UserCreationForm):
    username = forms.CharField(
        label="Nom d'utilisateur",
        widget=forms.TextInput(attrs={'placeholder': "Nom d'utilisateur"})
    )
    email = forms.EmailField(
        label="Adresse e-mail",
        widget=forms.EmailInput(attrs={'placeholder': "Adresse e-mail"})
    )
    password1 = forms.CharField(
        label="Mot de passe",
        strip=False,
        widget=forms.PasswordInput(attrs={'placeholder': "Mot de passe"}),
        help_text="Votre mot de passe doit contenir au moins 8 caractères, ne pas être trop simple, ni entièrement numérique."
    )
    password2 = forms.CharField(
        label="Confirmation du mot de passe",
        widget=forms.PasswordInput(attrs={'placeholder': "Répétez le mot de passe"}),
        strip=False,
        help_text="Entrez le même mot de passe pour vérification."
    )

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")

    def clean_password1(self):
        password = self.cleaned_data.get('password1')
        username = self.cleaned_data.get('username')

        if len(password) < 8:
            raise ValidationError("Le mot de passe doit contenir au moins 8 caractères.")
        if password.isdigit():
            raise ValidationError("Le mot de passe ne peut pas être uniquement composé de chiffres.")
        if username and username.lower() in password.lower():
            raise ValidationError("Le mot de passe ne doit pas être trop similaire au nom d'utilisateur.")
        if password.lower() in ['motdepasse', 'password', 'azerty', '12345678']:
            raise ValidationError("Le mot de passe est trop courant. Choisissez-en un autre.")
        return password
