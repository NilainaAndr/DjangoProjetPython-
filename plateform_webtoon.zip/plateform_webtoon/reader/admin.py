from django.contrib import admin
from .models import Manga, Chapter, Page

class PageInline(admin.TabularInline):
    model = Page
    extra = 1

class ChapterInline(admin.StackedInline):
    model = Chapter
    extra = 1

class ChapterAdmin(admin.ModelAdmin):
    list_display = ('title', 'manga', 'number', 'created_at')
    inlines = [PageInline]

class MangaAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at')
    inlines = [ChapterInline]

admin.site.register(Manga, MangaAdmin)
admin.site.register(Chapter, ChapterAdmin)
admin.site.register(Page)